import { configureStore } from "@reduxjs/toolkit";

import cartReducer from "../features/cart/cartSlice";
import productReducer from "../features/products/productSlice";
import wishlistReducer from "../features/wishList/wishListSlice";
import userReducer from "../features/user/userSlice";

export const store = configureStore({
  reducer: {
    cart: cartReducer,
    products: productReducer,
    wishlist: wishlistReducer,
    user: userReducer,
  },
  devTools: import.meta.env.DEV,
});

export default store;